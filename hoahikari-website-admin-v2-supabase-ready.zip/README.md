# HoaHikari Website + Admin

Bộ khung miễn phí gồm:
- Website công khai responsive.
- Admin đăng nhập bằng Supabase Auth.
- CRUD bài viết, kiến thức, roadmap, thông báo, tài liệu/video.
- Lên lịch theo `publish_date`.
- Cài đặt link app CCQG.
- Database + RLS trong `supabase/schema.sql`.

## Cài một lần
1. Tạo project miễn phí trên Supabase.
2. Mở SQL Editor và chạy toàn bộ `supabase/schema.sql`.
3. Tạo Email/Password user trong Authentication > Users.
4. Lấy Project URL + Publishable/Anon key.
5. Điền vào `config.js`.
6. Đưa toàn bộ thư mục lên GitHub repository và bật GitHub Pages.

## Ảnh
Admin đã có nút chọn ảnh trực tiếp từ máy. Ảnh được upload vào Storage bucket `hoahikari-images` và website dùng URL công khai của ảnh.

## App CCQG
Trong Admin > Cài đặt, dán link app hiện tại. Website sẽ mở app bằng nút "Mở app luyện đề".
