import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./config.js";

const demo = {
  site:{hero_text:"Kiến thức Kaigo · CCQG Kaigo · Roadmap · Kinh nghiệm Nhật Bản",app_url:"#"},
  notices:[{title:"Chào mừng đến với HoaHikari",body:"Nội dung mới sẽ được cập nhật tại đây.",active:true}],
  knowledge:[
    {title:"Mẹo thi Kaigo",body:"Học theo cấu trúc đề, hiểu mẫu câu và luyện đề có phân tích.",tag:"CCQG Kaigo"},
    {title:"介護過程",body:"Tập trung vào thông tin của người sử dụng, mục tiêu và quá trình hỗ trợ.",tag:"Kiến thức"},
    {title:"認知症",body:"Ưu tiên tôn trọng, lắng nghe và lấy người sử dụng làm trung tâm.",tag:"Kaigo"}
  ],
  roadmap:[
    {title:"Bước 1 · Nắm cấu trúc",body:"Hiểu môn thi, thời gian, dạng câu hỏi và cách phân bổ sức học."},
    {title:"Bước 2 · Học trọng tâm",body:"Học lý thuyết theo chủ đề và lập liên kết giữa kiến thức."},
    {title:"Bước 3 · Luyện đề",body:"Làm đề, phân tích sai và xây sổ tay mẹo thi."}
  ],
  posts:[],
  resources:[]
};

let db=null;
if(SUPABASE_URL.startsWith("http") && !SUPABASE_ANON_KEY.startsWith("YOUR_")) db=createClient(SUPABASE_URL,SUPABASE_ANON_KEY);

async function rows(table, fallback=[]){
  if(!db) return fallback;
  const today=new Date().toISOString().slice(0,10); const {data,error}=await db.from(table).select("*").eq("published",true).lte("publish_date",today).order("publish_date",{ascending:false});
  return error ? fallback : (data||[]);
}
function card(x){
  return `<article class="card">${x.image_url?`<img src="${x.image_url}" alt="">`:""}<div class="card-body">${x.tag?`<span class="tag">${x.tag}</span>`:""}<h3>${esc(x.title||"")}</h3><p class="muted">${esc(x.body||x.content||"")}</p>${x.url?`<a class="btn" href="${x.url}" target="_blank" rel="noopener">Mở</a>`:""}</div></article>`;
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
async function load(){
  const [site,notices,knowledge,roadmap,posts,resources]=await Promise.all([
    db?db.from("site_settings").select("*").limit(1).maybeSingle():Promise.resolve({data:demo.site}),
    rows("notices",demo.notices),rows("knowledge",demo.knowledge),rows("roadmap",demo.roadmap),rows("posts",demo.posts),rows("resources",demo.resources)
  ]);
  const s=site.data||demo.site; document.querySelector("#heroText").textContent=s.hero_text||demo.site.hero_text;
  const n=notices[0]; document.querySelector("#notice").textContent=n?`${n.title}: ${n.body}`:"";
  const today=posts.find(p=>p.publish_date===new Date().toISOString().slice(0,10))||posts[0];
  document.querySelector("#todayTitle").textContent=today?.title||"Chào mừng đến HoaHikari";
  document.querySelector("#todayText").textContent=today?.body||"Kiến thức mới sẽ được cập nhật tại đây.";
  document.querySelector("#knowledgeGrid").innerHTML=knowledge.length?knowledge.map(card).join(""):'<div class="empty">Chưa có nội dung.</div>';
  document.querySelector("#roadmapGrid").innerHTML=roadmap.length?roadmap.map(card).join(""):'<div class="empty">Chưa có nội dung.</div>';
  document.querySelector("#postsGrid").innerHTML=posts.length?posts.map(card).join(""):'<div class="empty">Chưa có bài viết.</div>';
  document.querySelector("#resourcesGrid").innerHTML=resources.length?resources.map(card).join(""):'<div class="empty">Chưa có tài liệu/video.</div>';
  document.querySelector("#appLink").href=s.app_url||"#"; document.querySelector("#year").textContent=new Date().getFullYear();
}
load();